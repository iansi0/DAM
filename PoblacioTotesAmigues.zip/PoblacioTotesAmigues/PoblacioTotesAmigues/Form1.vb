﻿Imports System.IO

Public Class Form1
    Dim line(6) As String
    Dim matrixEsp(,) As String
    Dim firstTime As Boolean = True
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim tmp As String
        Dim prov As String = "i"
        Dim fileLenght As Integer
        Dim sr As StreamReader

        Try
            sr = My.Computer.FileSystem.OpenTextFileReader(".\resources\prov.txt")

            fileLenght = File.ReadAllLines(".\resources\prov.txt").Length

            ReDim matrixEsp(6, fileLenght - 1)

            For i = 0 To matrixEsp.GetUpperBound(1)
                tmp = sr.ReadLine()
                line = tmp.Split(";")
                matrixEsp(0, i) = line(0)
                matrixEsp(1, i) = line(1)
                matrixEsp(2, i) = line(2)
                matrixEsp(3, i) = line(3)
                matrixEsp(4, i) = line(4)
                matrixEsp(5, i) = line(5)
                matrixEsp(6, i) = line(6)

                ComboBox2.Items.Add(line(3))
                ComboBox6.Items.Add(line(3))

                If Equals(prov, line(1)) = False Then
                    ComboBox1.Items.Add(line(1))
                    ComboBox4.Items.Add(line(1))

                End If
                prov = line(1)

            Next

        Catch ex As Exception

        End Try
    End Sub
    Private Sub SortirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SortirToolStripMenuItem.Click
        End
    End Sub

    Private Sub SobreMiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SobreMiToolStripMenuItem.Click
        Me.Hide()
        AboutBox1.Show()

    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim provSelected As String
        provSelected = ComboBox1.Text
        DataGridView1.Rows.Clear()

        For i = 0 To matrixEsp.GetUpperBound(1)
            If Equals(provSelected, matrixEsp.GetValue(1, i)) Then
                DataGridView1.Rows.Add(matrixEsp(2, i), matrixEsp(3, i), matrixEsp(4, i), matrixEsp(5, i), matrixEsp(6, i))
            End If
        Next

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        Dim pobSelected As String
        pobSelected = ComboBox2.Text
        DataGridView2.Rows.Clear()

        For i = 0 To matrixEsp.GetUpperBound(1)
            If Equals(pobSelected, matrixEsp.GetValue(3, i)) Then
                DataGridView2.Rows.Add(matrixEsp(0, i), matrixEsp(1, i), matrixEsp(4, i), matrixEsp(5, i), matrixEsp(6, i))
            End If
        Next

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim nHab As String

        DataGridView3.Rows.Clear()

        If TextBox1.Text = "" Then
            MessageBox.Show("Introdueix les dades necessaries!!")
        Else
            nHab = TextBox1.Text
            If ComboBox3.Text = "No Filtrar" Then

                If ComboBox5.Text = "=" Then
                    For i = 0 To matrixEsp.GetUpperBound(1)
                        If (matrixEsp.GetValue(4, i) = nHab) Then
                            DataGridView3.Rows.Add(matrixEsp(1, i), matrixEsp(3, i), matrixEsp(4, i), matrixEsp(5, i), matrixEsp(6, i))
                        End If

                    Next

                ElseIf ComboBox5.Text = "<"
                    For i = 0 To matrixEsp.GetUpperBound(1)
                        If Int(matrixEsp.GetValue(4, i)) < Int(nHab) Then
                            DataGridView3.Rows.Add(matrixEsp(1, i), matrixEsp(3, i), matrixEsp(4, i), matrixEsp(5, i), matrixEsp(6, i))
                        End If

                    Next

                ElseIf ComboBox5.Text = ">"
                    For i = 0 To matrixEsp.GetUpperBound(1)

                        If Int(matrixEsp.GetValue(4, i)) > Int(nHab) Then
                            DataGridView3.Rows.Add(matrixEsp(1, i), matrixEsp(3, i), matrixEsp(4, i), matrixEsp(5, i), matrixEsp(6, i))
                        End If

                    Next
                End If

            ElseIf ComboBox3.Text = "Home"
                If ComboBox5.Text = "=" Then
                    For i = 0 To matrixEsp.GetUpperBound(1)
                        If (matrixEsp.GetValue(5, i) = nHab) Then
                            DataGridView3.Rows.Add(matrixEsp(1, i), matrixEsp(3, i), matrixEsp(4, i), matrixEsp(5, i), "---")
                        End If

                    Next

                ElseIf ComboBox5.Text = "<"
                    For i = 0 To matrixEsp.GetUpperBound(1)
                        If Int(matrixEsp.GetValue(5, i)) < Int(nHab) Then
                            DataGridView3.Rows.Add(matrixEsp(1, i), matrixEsp(3, i), matrixEsp(4, i), matrixEsp(5, i), "---")
                        End If

                    Next

                ElseIf ComboBox5.Text = ">"
                    For i = 0 To matrixEsp.GetUpperBound(1)

                        If Int(matrixEsp.GetValue(5, i)) > Int(nHab) Then
                            DataGridView3.Rows.Add(matrixEsp(1, i), matrixEsp(3, i), matrixEsp(4, i), matrixEsp(5, i), "---")
                        End If

                    Next
                End If

            ElseIf ComboBox3.Text = "Dona"
                If ComboBox5.Text = "=" Then
                    For i = 0 To matrixEsp.GetUpperBound(1)
                        If (matrixEsp.GetValue(6, i) = nHab) Then
                            DataGridView3.Rows.Add(matrixEsp(1, i), matrixEsp(3, i), matrixEsp(4, i), "---", matrixEsp(6, i))
                        End If

                    Next

                ElseIf ComboBox5.Text = "<"
                    For i = 0 To matrixEsp.GetUpperBound(1)
                        If Int(matrixEsp.GetValue(6, i)) < Int(nHab) Then
                            DataGridView3.Rows.Add(matrixEsp(1, i), matrixEsp(3, i), matrixEsp(4, i), "---", matrixEsp(6, i))
                        End If

                    Next

                ElseIf ComboBox5.Text = ">"
                    For i = 0 To matrixEsp.GetUpperBound(1)
                        If Int(matrixEsp.GetValue(6, i)) > Int(nHab) Then
                            DataGridView3.Rows.Add(matrixEsp(1, i), matrixEsp(3, i), matrixEsp(4, i), "---", matrixEsp(6, i))
                        End If

                    Next
                End If
            End If
        End If

    End Sub

    Private Sub ComboBox4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox4.SelectedIndexChanged
        Dim numPob As Integer = 0
        Dim tmpProv As String
        tmpProv = ComboBox4.Text


        For i = 1 To matrixEsp.GetUpperBound(1)

            If Equals(tmpProv, matrixEsp(1, i)) = False And numPob > 0 Then
                TextBox2.Text = numPob
                numPob = 0

            ElseIf Equals(tmpProv, matrixEsp(1, i))
                numPob += 1

            End If

        Next

    End Sub

    Private Sub ComboBox6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox6.SelectedIndexChanged
        Dim tmpPob As String

        tmpPob = ComboBox6.Text

        For i = 0 To matrixEsp.GetUpperBound(1)
            If Equals(tmpPob, matrixEsp.GetValue(3, i)) Then
                TextBox3.Text = matrixEsp(1, i)
            End If
        Next
    End Sub
End Class
