﻿Imports AxMSWinsockLib

Public Class Form1
    Dim board(2, 2) As Button
    Dim boardString As String = ""
    Dim server As Boolean
    Dim moves As Integer
    Dim order As Boolean = False
    Dim victory As String = "HAS GUANYAT!"
    Dim timer As Integer = 10
    Dim serverWin As String = "f"
    Dim clientWin As String = "f"
    Dim dataStr As String = "DATA"

    Sub serverStatus()
        Select Case AxWinsock1.CtlState
            Case MSWinsockLib.StateConstants.sckClosed
                Label4.Text = "Tancat"
            Case MSWinsockLib.StateConstants.sckOpen
                Label4.Text = "Obert"
            Case MSWinsockLib.StateConstants.sckListening
                Label4.Text = "Escoltant"
            Case MSWinsockLib.StateConstants.sckConnectionPending
                Label4.Text = "Conexio Pendent"
            Case MSWinsockLib.StateConstants.sckResolvingHost
                Label4.Text = "Arreglant Host"
            Case MSWinsockLib.StateConstants.sckHostResolved
                Label4.Text = "Host Resolt"
            Case MSWinsockLib.StateConstants.sckConnecting
                Label4.Text = "Conectant..."
            Case MSWinsockLib.StateConstants.sckConnected
                Label4.Text = "Conectat!"
            Case MSWinsockLib.StateConstants.sckClosing
                Label4.Text = "Tancant..."
            Case MSWinsockLib.StateConstants.sckError
                Label4.Text = "Error!"
                AxWinsock1.Close()

        End Select

    End Sub
    Sub clientStatus()
        Select Case AxWinsock2.CtlState
            Case MSWinsockLib.StateConstants.sckClosed
                Label5.Text = "Tancat"
            Case MSWinsockLib.StateConstants.sckOpen
                Label5.Text = "Obert"
            Case MSWinsockLib.StateConstants.sckListening
                Label5.Text = "Escoltant"
            Case MSWinsockLib.StateConstants.sckConnectionPending
                Label5.Text = "Conexio Pendent"
            Case MSWinsockLib.StateConstants.sckResolvingHost
                Label5.Text = "Arreglant Host"
            Case MSWinsockLib.StateConstants.sckHostResolved
                Label5.Text = "Host Resolt"
            Case MSWinsockLib.StateConstants.sckConnecting
                Label5.Text = "Conectat!"
            Case MSWinsockLib.StateConstants.sckConnected
                Label5.Text = "Conectat!"
            Case MSWinsockLib.StateConstants.sckClosing
                Label5.Text = "Tancant..."
            Case MSWinsockLib.StateConstants.sckError
                Label5.Text = "Error!"
                AxWinsock2.Close()

        End Select

    End Sub

    Private Function getDataToUpdateBoardFunction()
        Dim count As Integer = 0
        boardString = ""
        For row As Integer = 0 To 2
            For col As Integer = 0 To 2
                If board(row, col).Tag = 0 Then
                    boardString += "0"
                    count += 1
                Else
                    boardString += board(row, col).Tag.ToString
                End If
            Next
        Next
        If count = 0 Then
            boardString = "e" + boardString
            Label9.Text = "Empat"
        End If
    End Function

    Private Function UpdateBoardFunction(updateboard As String)
        Dim runnerHelper As Integer = 0
        Dim numbers As New List(Of Integer)
        For Each c As Char In updateboard
            If c = "0" Then
                numbers.Add(0)
            ElseIf c = "1"
                numbers.Add(1)
            Else
                numbers.Add(2)
            End If
        Next
        For row As Integer = 0 To 2
            For col As Integer = 0 To 2
                Dim data As Integer = numbers(runnerHelper)
                If data = 0 Then
                    board(row, col).Tag = Nothing
                Else
                    board(row, col).Tag = data
                End If
                If data = 1 Then
                    board(row, col).Text = "X"
                    board(row, col).BackColor = Color.DarkGreen
                    board(row, col).ForeColor = Color.WhiteSmoke
                ElseIf data = 2
                    board(row, col).Text = "O"
                    board(row, col).BackColor = Color.DarkRed
                    board(row, col).ForeColor = Color.WhiteSmoke
                End If
                If data <> 0 Then
                    board(row, col).Enabled = False
                Else
                    board(row, col).Enabled = True
                End If
                runnerHelper += 1
            Next
        Next
        If serverWin = "t" Or clientWin = "t" Or clientWin = "e" Then
            Timer1.Enabled = False
        Else
            Timer1.Enabled = True
        End If
        runnerHelper = 0
        timer = 10
        Label7.Text = timer
    End Function

    Private Function HasWinner(board As Button(,)) As Boolean
        For row As Integer = 0 To 2
            If board(row, 0).Tag And board(row, 1).Tag And board(row, 2).Tag Then
                If server = True Then
                    serverWin = "t"
                    getDataToUpdateBoardFunction()
                    AxWinsock1.SendData(serverWin)
                    AxWinsock1.SendData(boardString)
                Else
                    clientWin = "t"
                    getDataToUpdateBoardFunction()
                    AxWinsock2.SendData(clientWin)
                    AxWinsock2.SendData(boardString)
                End If
                clientWin = "f"
                Return True
            End If
        Next
        For col As Integer = 0 To 2
            If board(0, col).Tag And board(1, col).Tag And board(2, col).Tag Then
                If server = True Then
                    serverWin = "t"
                    getDataToUpdateBoardFunction()
                    AxWinsock1.SendData(serverWin)
                    AxWinsock1.SendData(boardString)
                Else
                    clientWin = "t"
                    getDataToUpdateBoardFunction()
                    AxWinsock2.SendData(clientWin)
                    AxWinsock2.SendData(boardString)
                End If
                clientWin = "f"
                Return True
            End If
        Next
        If board(0, 0).Tag And board(1, 1).Tag And board(2, 2).Tag Then
            If server = True Then
                serverWin = "t"
                getDataToUpdateBoardFunction()
                AxWinsock1.SendData(serverWin)
                AxWinsock1.SendData(boardString)
            Else
                clientWin = "t"
                getDataToUpdateBoardFunction()
                AxWinsock2.SendData(clientWin)
                AxWinsock2.SendData(boardString)
            End If
            clientWin = "f"
            Return True
        End If
        If board(2, 0).Tag And board(1, 1).Tag And board(0, 2).Tag Then
            If server = True Then
                serverWin = "t"
                getDataToUpdateBoardFunction()
                AxWinsock1.SendData(serverWin)
                AxWinsock1.SendData(boardString)
            Else
                clientWin = "t"
                getDataToUpdateBoardFunction()
                AxWinsock2.SendData(clientWin)
                AxWinsock2.SendData(boardString)
            End If
            clientWin = "f"
            Return True
        End If
        If server = True Then
            getDataToUpdateBoardFunction()
            AxWinsock1.SendData(boardString)
        Else
            getDataToUpdateBoardFunction()
            AxWinsock2.SendData(boardString)
        End If
        Return False
    End Function


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label2.Text = "" & AxWinsock1.LocalIP
        serverStatus()

        Label9.Visible = False

        board(0, 0) = Button3
        board(0, 1) = Button4
        board(0, 2) = Button5
        board(1, 0) = Button6
        board(1, 1) = Button7
        board(1, 2) = Button8
        board(2, 0) = Button9
        board(2, 1) = Button10
        board(2, 2) = Button11
        Label7.Text = timer.ToString


    End Sub
    Private Sub SortirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SortirToolStripMenuItem.Click
        End
    End Sub

    Private Sub AcercaDeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcercaDeToolStripMenuItem.Click
        AboutBox1.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AxWinsock1.Listen()
        serverStatus()
        Button1.Enabled = False
        GroupBox2.Visible = False
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Button2.Enabled = False


        Dim result As DialogResult
        Dim form As New Form
        form.Size = New Size(350, 190)
        form.FormBorderStyle = FormBorderStyle.FixedDialog
        form.StartPosition = FormStartPosition.CenterScreen
        form.ControlBox = False
        form.BackColor = Color.Moccasin
        form.Text = "Introdueix la IP del Servidor"

        Dim textbox As New TextBox
        textbox.Location = New Point(20, 30)
        textbox.Size = New Size(250, 20)
        form.Controls.Add(textbox)

        Dim okButton As New Button
        okButton.Location = New Point(150, 90)
        okButton.Size = New Size(100, 30)
        okButton.Text = "Acceptar"
        okButton.BackColor = Color.Sienna
        AddHandler okButton.Click, Sub(senders, es)
                                       result = DialogResult.OK
                                       form.Close()
                                   End Sub
        form.Controls.Add(okButton)

        Dim cancelButton As New Button
        cancelButton.Location = New Point(20, 90)
        cancelButton.Size = New Size(100, 30)
        cancelButton.Text = "Cancelar"
        cancelButton.BackColor = Color.Sienna
        AddHandler cancelButton.Click, Sub(senders, es)
                                           result = DialogResult.Cancel
                                           Button2.Enabled = True
                                           form.Close()
                                       End Sub
        form.Controls.Add(cancelButton)

        form.ShowDialog()
        If result = DialogResult.OK Then
            If textbox.Text = "" Then
                Button2.Enabled = True
                MessageBox.Show("Error! No has introduit cap IP")
                GroupBox1.Visible = True
                Label5.Text = "Error en la IP"
                form.Close()

            ElseIf AxWinsock2.CtlState = MSWinsockLib.StateConstants.sckClosed Then
                AxWinsock2.RemoteHost = textbox.Text
                AxWinsock2.Connect()

                clientStatus()

                GroupBox1.Visible = False
                Label9.Text = "S'ha trobat partida"
                Button12.Visible = False
                form.Close()
            End If
        End If

    End Sub

    Private Sub AxWinsock1_ConnectionRequest(sender As Object, e As DMSWinsockControlEvents_ConnectionRequestEvent) Handles AxWinsock1.ConnectionRequest
        If AxWinsock1.CtlState <> MSWinsockLib.StateConstants.sckConnected Then   ' Si no està connectat
            AxWinsock1.Close()
            serverStatus()
            AxWinsock1.Accept(e.requestID)

            If order = False Then
                Label9.Visible = True
                Label9.Text = "S'ha trobat partida"

                AxWinsock1.SendData(Label9.Text)

                MessageBox.Show("Conexio Realitzada")
                server = True
            End If
        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label7.Text = timer
        If timer = 0 Then
            Timer1.Stop()
            HasWinner(board)
            timer = 10

        End If
        timer -= 1


    End Sub

    Private Sub Button_MouseClick(sender As Object, e As MouseEventArgs) Handles Button3.MouseClick, Button4.MouseClick, Button5.MouseClick, Button6.MouseClick, Button7.MouseClick, Button8.MouseClick, Button9.MouseClick, Button10.MouseClick, Button11.MouseClick
        Dim buttonTmp As Button = DirectCast(sender, Button)
        If Timer1.Enabled = True And serverWin = "f" And clientWin = "f" Then
            Label7.Text = timer
            If e.Button = MouseButtons.Left Then
                If buttonTmp.ClientRectangle.Contains(e.Location) And buttonTmp.Enabled = True Then
                    If server = True Then
                        buttonTmp.Text = "X"
                        buttonTmp.BackColor = Color.DarkGreen
                        buttonTmp.ForeColor = Color.WhiteSmoke
                        buttonTmp.Tag = 1
                    Else
                        buttonTmp.Text = "O"
                        buttonTmp.BackColor = Color.DarkRed
                        buttonTmp.ForeColor = Color.WhiteSmoke
                        buttonTmp.Tag = 2
                    End If
                End If
                Timer1.Enabled = False
                buttonTmp.Enabled = False

                If HasWinner(board) Then
                    If server = False Then
                        Label9.Text = "Guanyador"

                    ElseIf server = True
                        Label9.Text = "Guanyador"
                    End If
                    Timer1.Stop()
                End If
            End If
        End If


    End Sub

    Private Sub AxWinsock1_DataArrival(sender As Object, e As DMSWinsockControlEvents_DataArrivalEvent) Handles AxWinsock1.DataArrival
        If Label9.Text = "En partida" Then
            AxWinsock1.GetData(boardString)
            If boardString(0) = "t" Then
                clientWin = boardString(0)

                boardString = boardString.Substring(1, 9)
                Label9.Text = "Has perdut"
            End If
            UpdateBoardFunction(boardString)
            Exit Sub
        End If


    End Sub

    Private Sub AxWinsock2_DataArrival(sender As Object, e As DMSWinsockControlEvents_DataArrivalEvent) Handles AxWinsock2.DataArrival
        If Label9.Text = "No s'ha trobat partida" Then
            AxWinsock2.GetData(dataStr)
            Label9.Text = dataStr
            Exit Sub
        End If
        If Label9.Text = "S'ha trobat partida" Then
            Button2.Enabled = False
            AxWinsock2.GetData(dataStr)
            Label9.Text = dataStr
            Exit Sub
        End If
        If Label9.Text = "En partida" Then
            AxWinsock2.GetData(boardString)
            If boardString(0) = "t" Then
                serverWin = boardString(0)
                boardString = boardString.Substring(1, 9)
                Label9.Text = "Perdedor"
            ElseIf boardString(0) = "e"
                clientWin = boardString(0)
                boardString = boardString.Substring(1, 9)
                Label9.Text = "Empat"
            End If
            UpdateBoardFunction(boardString)
            Exit Sub
        End If


    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        If Label9.Text = "S'ha trobat partida" Then

            Label9.Text = "En partida"
            AxWinsock1.SendData(Label9.Text)
            Timer1.Start()
            Button12.Enabled = False
        Else
            MessageBox.Show("No estas conectat")
        End If
    End Sub
End Class
