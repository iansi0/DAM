﻿Imports System.ComponentModel

Public Class Form1
    Dim sw As New Stopwatch()
    Dim min As Integer
    Dim sec As Integer
    Dim minutes As String
    Dim seconds As String
    Dim count As Integer
    Dim angleizq1 As Double = ((1 / 2) * Math.PI)
    Dim angleizq2 As Double = ((1 / 2) * Math.PI)
    Dim angleizq3 As Double = ((1 / 2) * Math.PI)
    Dim angleizq4 As Double = ((1 / 2) * Math.PI)
    Dim angleder1 As Double = -((3 / 2) * Math.PI)
    Dim angleder2 As Double = -((3 / 2) * Math.PI)
    Dim angleder3 As Double = -((3 / 2) * Math.PI)
    Dim angleder4 As Double = -((3 / 2) * Math.PI)
    Dim pictureLocationX1 As Integer
    Dim pictureLocationY1 As Integer
    Dim pictureLocation1 As Point
    Dim pictureLocationX2 As Integer
    Dim pictureLocationY2 As Integer
    Dim pictureLocation2 As Point
    Dim pictureLocationX3 As Integer
    Dim pictureLocationY3 As Integer
    Dim pictureLocation3 As Point
    Dim pictureLocationX4 As Integer
    Dim pictureLocationY4 As Integer
    Dim pictureLocation4 As Point
    Dim radi1 As Integer
    Dim radi2 As Integer
    Dim radi3 As Integer
    Dim radi4 As Integer
    Dim time As Integer = 50


    Private Function movimentLineal(posX As Integer, posY As Integer)
        Dim x As Integer
        Dim velocitat As Integer

        If posX <= 1210 And posX > 880 And posY > 240 Then
            velocitat = New Random().Next(1, 8)
            x = posX + velocitat

        ElseIf posX <= 1210 And posX > 880 And posY <= 240 Then
            velocitat = New Random().Next(1, 8)
            x = posX - velocitat

        Else
            x = posX
        End If

        Return x

    End Function

    Private Function movimentCurva(radi As Integer, girizq As Boolean, angle As Double)
        Dim array(2) As Double
        Dim x As Integer = 0
        Dim y As Integer = 0
        Dim rand As Double

        If girizq = True Then
            x = 880 + (radi * Math.Cos(angle))
            y = 270 - (radi * Math.Sin(angle))
            rand = (0.03 * Rnd()) + 0.01
            angle = angle + rand

        Else
            x = Int(1200 - radi * Math.Cos(angle))
            y = Int(272 + radi * Math.Sin(angle))
            rand = (0.03 * Rnd()) + 0.01
            angle = angle + rand


            'If angle > 2 * Math.PI Then
            '    angle = 0
            'End If
        End If

        array(0) = x
        array(1) = y
        array(2) = angle
        Return array
    End Function

    Private Sub SortirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SortirToolStripMenuItem.Click
        End
    End Sub

    Private Sub AcercaDeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcercaDeToolStripMenuItem.Click
        Me.Hide()
        AboutBox1.Show()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        min = 0
        sec = 0

        BackgroundWorker1.WorkerReportsProgress = True
        BackgroundWorker2.WorkerReportsProgress = True
        BackgroundWorker3.WorkerReportsProgress = True
        BackgroundWorker4.WorkerReportsProgress = True


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RadioButton1.Enabled = True
        RadioButton2.Enabled = True
        RadioButton3.Enabled = True
        RadioButton4.Enabled = True
        Button2.Enabled = True
        TextBox1.Enabled = True
        Timer1.Enabled = True
        sec = sec + 1
        minutes = min.ToString
        seconds = sec.ToString
        BackgroundWorker1.RunWorkerAsync()
        BackgroundWorker2.RunWorkerAsync()
        BackgroundWorker3.RunWorkerAsync()
        BackgroundWorker4.RunWorkerAsync()
        count = 0
        Button1.Enabled = False
        sw.Start()



    End Sub



    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Contador antic
        'If (min < 10) Then
        '    minutes = "0" + min.ToString
        'Else
        '    minutes = min.ToString
        'End If
        'If (sec < 10) Then
        '    seconds = "0" + sec.ToString
        'Else
        '    seconds = sec.ToString
        'End If
        'If (sec = 59) Then
        '    min = min + 1
        '    sec = -1
        'End If
        'sec = sec + 1
        'TextBox1.Text = minutes + ":" + seconds

        Dim elapsed_time As TimeSpan = sw.Elapsed
        Dim formatted_time As String = String.Format("{0:00}:{1:00}:{2:000}", elapsed_time.Minutes, elapsed_time.Seconds, elapsed_time.Milliseconds)
        TextBox1.Text = formatted_time

        If count = 4 Then
            Timer1.Stop()
            Button2.Enabled = False
        End If

        If PictureBox2.Enabled = True And (PictureBox2.Location.X <= PictureBox6.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox2.Enabled = False
            PictureBox6.Enabled = True
            TextBox4.Text = TextBox4.Text + vbCrLf + Label1.Text + " " + TextBox1.Text
        End If

        If PictureBox6.Enabled = True And (PictureBox6.Location.Y >= PictureBox10.Location.Y And PictureBox6.Location.X >= PictureBox10.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox6.Enabled = False
            PictureBox10.Enabled = True
            TextBox5.Text = TextBox5.Text + vbCrLf + Label1.Text + " " + TextBox1.Text

        End If

        If PictureBox10.Enabled = True And (PictureBox10.Location.X >= PictureBox14.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox10.Enabled = False
            PictureBox14.Enabled = True
            TextBox6.Text = TextBox6.Text + vbCrLf + Label1.Text + " " + TextBox1.Text
        End If

        If PictureBox14.Enabled = True And (PictureBox14.Location.Y <= 146 And PictureBox14.Location.X <= PictureBox19.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox14.Enabled = False
            TextBox2.Text = TextBox2.Text + vbCrLf + Label1.Text + " " + TextBox1.Text
            RadioButton1.Enabled = False
            count += 1
        End If


        If PictureBox3.Enabled = True And (PictureBox3.Location.X <= PictureBox7.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox3.Enabled = False
            PictureBox7.Enabled = True
            TextBox4.Text = TextBox4.Text + vbCrLf + Label2.Text + " " + TextBox1.Text
        End If

        If PictureBox7.Enabled = True And (PictureBox7.Location.Y >= PictureBox11.Location.Y And PictureBox7.Location.X >= PictureBox11.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox7.Enabled = False
            PictureBox11.Enabled = True
            TextBox5.Text = TextBox5.Text + vbCrLf + Label2.Text + " " + TextBox1.Text
        End If

        If PictureBox11.Enabled = True And (PictureBox11.Location.X >= PictureBox15.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox11.Enabled = False
            PictureBox15.Enabled = True
            TextBox6.Text = TextBox6.Text + vbCrLf + Label2.Text + " " + TextBox1.Text
        End If

        If PictureBox15.Enabled = True And (PictureBox15.Location.Y <= 146 And PictureBox15.Location.X <= PictureBox19.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox15.Enabled = False
            TextBox2.Text = TextBox2.Text + vbCrLf + Label2.Text + " " + TextBox1.Text
            RadioButton2.Enabled = False
            count += 1
        End If


        If PictureBox4.Enabled = True And (PictureBox4.Location.X <= PictureBox8.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox4.Enabled = False
            PictureBox8.Enabled = True
            TextBox4.Text = TextBox4.Text + vbCrLf + Label3.Text + " " + TextBox1.Text
        End If

        If PictureBox8.Enabled = True And (PictureBox8.Location.Y >= PictureBox12.Location.Y And PictureBox8.Location.X >= PictureBox12.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox8.Enabled = False
            PictureBox12.Enabled = True
            TextBox5.Text = TextBox5.Text + vbCrLf + Label3.Text + " " + TextBox1.Text
        End If

        If PictureBox12.Enabled = True And (PictureBox12.Location.X >= PictureBox16.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox12.Enabled = False
            PictureBox16.Enabled = True
            TextBox6.Text = TextBox6.Text + vbCrLf + Label3.Text + " " + TextBox1.Text
        End If

        If PictureBox16.Enabled = True And (PictureBox16.Location.Y <= 146 And PictureBox16.Location.X <= PictureBox19.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox16.Enabled = False
            TextBox2.Text = TextBox2.Text + vbCrLf + Label3.Text + " " + TextBox1.Text
            RadioButton3.Enabled = False
            count += 1
        End If


        If PictureBox5.Enabled = True And (PictureBox5.Location.X <= PictureBox9.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox5.Enabled = False
            PictureBox9.Enabled = True
            TextBox4.Text = TextBox4.Text + vbCrLf + Label4.Text + " " + TextBox1.Text
        End If

        If PictureBox9.Enabled = True And (PictureBox9.Location.Y >= PictureBox13.Location.Y And PictureBox9.Location.X >= PictureBox13.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox9.Enabled = False
            PictureBox13.Enabled = True
            TextBox5.Text = TextBox5.Text + vbCrLf + Label4.Text + " " + TextBox1.Text
        End If

        If PictureBox13.Enabled = True And (PictureBox13.Location.X >= PictureBox17.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox13.Enabled = False
            PictureBox17.Enabled = True
            TextBox6.Text = TextBox6.Text + vbCrLf + Label4.Text + " " + TextBox1.Text
        End If

        If PictureBox17.Enabled = True And (PictureBox17.Location.Y <= 146 And PictureBox17.Location.X <= PictureBox19.Location.X Or BackgroundWorker1.CancellationPending) Then
            PictureBox17.Enabled = False
            TextBox2.Text = TextBox2.Text + vbCrLf + Label4.Text + " " + TextBox1.Text
            RadioButton4.Enabled = False
            count += 1
        End If

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If RadioButton1.Checked = True And RadioButton1.Enabled = True Then
            PictureBox2.Enabled = False
            PictureBox6.Enabled = False
            PictureBox10.Enabled = False
            PictureBox14.Enabled = False
            TextBox3.Text = TextBox3.Text + vbCrLf + Label1.Text + " " + TextBox1.Text
            count += 1
            RadioButton1.Enabled = False
        End If
        If RadioButton2.Checked = True And RadioButton2.Enabled = True Then
            PictureBox3.Enabled = False
            PictureBox7.Enabled = False
            PictureBox11.Enabled = False
            PictureBox15.Enabled = False
            TextBox3.Text = TextBox3.Text + vbCrLf + Label2.Text + " " + TextBox1.Text
            count += 1
            RadioButton2.Enabled = False
        End If
        If RadioButton3.Checked = True And RadioButton3.Enabled = True Then
            PictureBox4.Enabled = False
            PictureBox8.Enabled = False
            PictureBox12.Enabled = False
            PictureBox16.Enabled = False
            TextBox3.Text = TextBox3.Text + vbCrLf + Label3.Text + " " + TextBox1.Text
            count += 1
            RadioButton3.Enabled = False
        End If
        If RadioButton4.Checked = True And RadioButton4.Enabled = True Then
            PictureBox5.Enabled = False
            PictureBox9.Enabled = False
            PictureBox13.Enabled = False
            PictureBox17.Enabled = False
            TextBox3.Text = TextBox3.Text + vbCrLf + Label4.Text + " " + TextBox1.Text
            count += 1
            RadioButton4.Enabled = False
        End If
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        If (PictureBox2.Enabled = True) Then
            Do While PictureBox2.Enabled = True
                pictureLocationY1 = PictureBox2.Location.Y
                pictureLocationX1 = PictureBox2.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker1.ReportProgress(0)
            Loop
        End If

        If (PictureBox6.Enabled = True) Then
            radi1 = PictureBox6.Tag
            Do While PictureBox6.Enabled = True
                pictureLocationY1 = PictureBox6.Location.Y
                pictureLocationX1 = PictureBox6.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker1.ReportProgress(0)
            Loop

        End If

        If (PictureBox10.Enabled = True) Then
            Do While PictureBox10.Enabled = True
                pictureLocationY1 = PictureBox10.Location.Y
                pictureLocationX1 = PictureBox10.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker1.ReportProgress(0)
            Loop

        End If

        If (PictureBox14.Enabled = True) Then
            radi1 = PictureBox14.Tag
            Do While PictureBox14.Enabled = True
                pictureLocationY1 = PictureBox14.Location.Y
                pictureLocationX1 = PictureBox14.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker1.ReportProgress(0)
            Loop

        End If
    End Sub

    Private Sub BackgroundWorker1_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        Dim x, y As Integer
        Dim girizq1 As Boolean
        Dim pos1(2) As Double

        If PictureBox2.Enabled = True Then
            x = movimentLineal(pictureLocationX1, pictureLocationY1)
            y = pictureLocationY1
            PictureBox2.Location = New Point(x, y)
        End If
        If PictureBox6.Enabled = True Then
            girizq1 = True
            pos1 = movimentCurva(radi1, girizq1, angleizq1)
            PictureBox6.Location = New Point(pos1(0), pos1(1))
            angleizq1 = pos1(2)
        End If
        If PictureBox10.Enabled = True Then
            x = movimentLineal(pictureLocationX1, pictureLocationY1)
            y = pictureLocationY1
            PictureBox10.Location = New Point(x, y)
        End If
        If PictureBox14.Enabled = True Then
            girizq1 = False
            pos1 = movimentCurva(radi1, girizq1, angleder1)
            PictureBox14.Location = New Point(pos1(0), pos1(1))
            angleder1 = pos1(2)
        End If

    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted

    End Sub

    Private Sub BackgroundWorker2_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker2.DoWork
        If (PictureBox3.Enabled = True) Then
            Do While PictureBox3.Enabled = True
                pictureLocationY2 = PictureBox3.Location.Y
                pictureLocationX2 = PictureBox3.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker2.ReportProgress(0)
            Loop
        End If

        If (PictureBox7.Enabled = True) Then
            radi2 = PictureBox7.Tag
            Do While PictureBox7.Enabled = True
                pictureLocationY2 = PictureBox7.Location.Y
                pictureLocationX2 = PictureBox7.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker2.ReportProgress(0)
            Loop

        End If

        If (PictureBox11.Enabled = True) Then
            Do While PictureBox11.Enabled = True
                pictureLocationY2 = PictureBox11.Location.Y
                pictureLocationX2 = PictureBox11.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker2.ReportProgress(0)
            Loop

        End If

        If (PictureBox15.Enabled = True) Then
            radi2 = PictureBox15.Tag
            Do While PictureBox15.Enabled = True
                pictureLocationY2 = PictureBox15.Location.Y
                pictureLocationX2 = PictureBox15.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker2.ReportProgress(0)
            Loop

        End If
    End Sub

    Private Sub BackgroundWorker2_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker2.ProgressChanged
        Dim x, y As Integer
        Dim girizq2 As Boolean
        Dim pos2(2) As Double

        If PictureBox3.Enabled = True Then
            x = movimentLineal(pictureLocationX2, pictureLocationY2)
            y = pictureLocationY2
            PictureBox3.Location = New Point(x, y)
        End If
        If PictureBox7.Enabled = True Then
            girizq2 = True
            pos2 = movimentCurva(radi2, girizq2, angleizq2)
            PictureBox7.Location = New Point(pos2(0), pos2(1))
            angleizq2 = pos2(2)
        End If
        If PictureBox11.Enabled = True Then
            x = movimentLineal(pictureLocationX2, pictureLocationY2)
            y = pictureLocationY2
            PictureBox11.Location = New Point(x, y)
        End If
        If PictureBox15.Enabled = True Then
            girizq2 = False
            pos2 = movimentCurva(radi2, girizq2, angleder2)
            PictureBox15.Location = New Point(pos2(0), pos2(1))
            angleder2 = pos2(2)
        End If

    End Sub

    Private Sub BackgroundWorker2_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker2.RunWorkerCompleted

    End Sub
    Private Sub BackgroundWorker3_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker3.DoWork
        If (PictureBox4.Enabled = True) Then
            Do While PictureBox4.Enabled = True
                pictureLocationY3 = PictureBox4.Location.Y
                pictureLocationX3 = PictureBox4.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker3.ReportProgress(0)
            Loop
        End If

        If (PictureBox8.Enabled = True) Then
            radi3 = PictureBox8.Tag
            Do While PictureBox8.Enabled = True
                pictureLocationY3 = PictureBox8.Location.Y
                pictureLocationX3 = PictureBox8.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker3.ReportProgress(0)
            Loop

        End If

        If (PictureBox12.Enabled = True) Then
            Do While PictureBox12.Enabled = True
                pictureLocationY3 = PictureBox12.Location.Y
                pictureLocationX3 = PictureBox12.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker3.ReportProgress(0)
            Loop

        End If

        If (PictureBox16.Enabled = True) Then
            radi3 = PictureBox16.Tag
            Do While PictureBox16.Enabled = True
                pictureLocationY3 = PictureBox16.Location.Y
                pictureLocationX3 = PictureBox16.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker3.ReportProgress(0)
            Loop

        End If
    End Sub

    Private Sub BackgroundWorker3_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker3.ProgressChanged
        Dim x, y As Integer
        Dim girizq3 As Boolean
        Dim pos3(2) As Double

        If PictureBox4.Enabled = True Then
            x = movimentLineal(pictureLocationX3, pictureLocationY3)
            y = pictureLocationY3
            PictureBox4.Location = New Point(x, y)
        End If
        If PictureBox8.Enabled = True Then
            girizq3 = True
            pos3 = movimentCurva(radi3, girizq3, angleizq3)
            PictureBox8.Location = New Point(pos3(0), pos3(1))
            angleizq3 = pos3(2)
        End If
        If PictureBox12.Enabled = True Then
            x = movimentLineal(pictureLocationX3, pictureLocationY3)
            y = pictureLocationY3
            PictureBox12.Location = New Point(x, y)
        End If
        If PictureBox16.Enabled = True Then
            girizq3 = False
            pos3 = movimentCurva(radi3, girizq3, angleder3)
            PictureBox16.Location = New Point(pos3(0), pos3(1))
            angleder3 = pos3(2)
        End If
    End Sub

    Private Sub BackgroundWorker3_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker3.RunWorkerCompleted

    End Sub

    Private Sub BackgroundWorker4_DoWork(sender As Object, e As DoWorkEventArgs) Handles BackgroundWorker4.DoWork
        If (PictureBox5.Enabled = True) Then
            Do While PictureBox5.Enabled = True
                pictureLocationY4 = PictureBox5.Location.Y
                pictureLocationX4 = PictureBox5.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker4.ReportProgress(0)
            Loop
        End If

        If (PictureBox9.Enabled = True) Then
            radi4 = PictureBox9.Tag
            Do While PictureBox9.Enabled = True
                pictureLocationY4 = PictureBox9.Location.Y
                pictureLocationX4 = PictureBox9.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker4.ReportProgress(0)
            Loop

        End If

        If (PictureBox13.Enabled = True) Then
            Do While PictureBox13.Enabled = True
                pictureLocationY4 = PictureBox13.Location.Y
                pictureLocationX4 = PictureBox13.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker4.ReportProgress(0)
            Loop

        End If

        If (PictureBox17.Enabled = True) Then
            radi4 = PictureBox17.Tag
            Do While PictureBox17.Enabled = True
                pictureLocationY4 = PictureBox17.Location.Y
                pictureLocationX4 = PictureBox17.Location.X
                System.Threading.Thread.Sleep(time)
                BackgroundWorker4.ReportProgress(0)
            Loop

        End If
    End Sub

    Private Sub BackgroundWorker4_ProgressChanged(sender As Object, e As ProgressChangedEventArgs) Handles BackgroundWorker4.ProgressChanged
        Dim x, y As Integer
        Dim girizq As Boolean
        Dim pos4(2) As Double

        If PictureBox5.Enabled = True Then
            x = movimentLineal(pictureLocationX4, pictureLocationY4)
            y = pictureLocationY4
            PictureBox5.Location = New Point(x, y)
        End If
        If PictureBox9.Enabled = True Then
            girizq = True
            pos4 = movimentCurva(radi4, girizq, angleizq4)
            PictureBox9.Location = New Point(pos4(0), pos4(1))
            angleizq4 = pos4(2)
        End If
        If PictureBox13.Enabled = True Then
            x = movimentLineal(pictureLocationX4, pictureLocationY4)
            y = pictureLocationY4
            PictureBox13.Location = New Point(x, y)
        End If
        If PictureBox17.Enabled = True Then
            girizq = False
            pos4 = movimentCurva(radi4, girizq, angleder4)
            PictureBox17.Location = New Point(pos4(0), pos4(1))
            angleder4 = pos4(2)
        End If
    End Sub

    Private Sub BackgroundWorker4_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles BackgroundWorker4.RunWorkerCompleted

    End Sub

End Class
