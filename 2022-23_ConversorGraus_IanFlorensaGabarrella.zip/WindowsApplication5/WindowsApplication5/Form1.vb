﻿Public Class Form1
    Dim c As Double
    Dim f As Double
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        End
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        c = Val(TextBox1.Text)
        If HScrollBar1.Enabled = True Then
            HScrollBar1.Value = c
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        f = Val(TextBox1.Text)
        If HScrollBar2.Enabled = True Then
            HScrollBar2.Value = f
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If InStr(1, "0123456789-" & Chr(8), e.KeyChar) = 0 And Len(TextBox2.Text) = 0 Then
            e.Handled = True
        End If
        If InStr(1, "0123456789." & Chr(8), e.KeyChar) = 0 And Len(TextBox2.Text) > 0 Then
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If InStr(1, "0123456789-" & Chr(8), e.KeyChar) = 0 And Len(TextBox1.Text) = 0 Then
            e.Handled = True
        End If
        If InStr(1, "0123456789." & Chr(8), e.KeyChar) = 0 And Len(TextBox1.Text) > 0 Then
            e.Handled = True
        End If
    End Sub

    Private Sub HScrollBar1_Scroll(sender As Object, e As ScrollEventArgs) Handles HScrollBar1.Scroll
        c = HScrollBar1.Value
        TextBox1.Text = c
        TextBox2.Text = Math.Round(((c * 9) / 5) + 32, 2)
    End Sub

    Private Sub TextBox2_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyUp
        If e.KeyCode = Keys.Return Then
            TextBox1.Text = Math.Round((f - 32) * (5 / 9), 2)
        End If
    End Sub

    Private Sub TextBox1_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyUp
        If e.KeyCode = Keys.Return Then
            TextBox2.Text = Math.Round(((c * 9) / 5) + 32, 2)
        End If
    End Sub

    Private Sub HScrollBar2_Scroll(sender As Object, e As ScrollEventArgs) Handles HScrollBar2.Scroll
        f = HScrollBar2.Value
        TextBox2.Text = f
        TextBox1.Text = Math.Round((f - 32) * (5 / 9), 2)
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        HScrollBar1.Enabled = False
        HScrollBar2.Enabled = False
        TextBox1.ReadOnly = False
        TextBox2.ReadOnly = False
        TextBox2.Clear()
        TextBox1.Clear()

    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        HScrollBar1.Enabled = True
        HScrollBar2.Enabled = True
        TextBox1.ReadOnly = True
        TextBox2.ReadOnly = True

    End Sub
    Private Sub SortirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SortirToolStripMenuItem.Click
        PictureBox1.Visible = True
    End Sub
End Class
