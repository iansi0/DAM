﻿Public Class Form1

    Private Sub listarDatos()
        'TODO: esta línea de código carga datos en la tabla 'DataSet1.Categorías' Puede moverla o quitarla según sea necesario.
        Me.CategoriaTableAdapter.Fill(Me.NeptunoDataSet1.Categoria)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'NeptunoDataSet1.Categoria' Puede moverla o quitarla según sea necesario.
        Me.CategoriaTableAdapter.Fill(Me.NeptunoDataSet1.Categoria)
        Me.listarDatos()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Actualizar fila usando el método find que recibe como parámetro el Id de la tabla. (IdCategoria)
        Dim fila As DataRow = Me.NeptunoDataSet1.Categoria.Rows.Find(Me.DataGridView1.SelectedCells(0).Value)
        Me.TextBox1.Enabled = False
        fila(1) = Me.TextBox2.Text  'Editar datos
        fila(2) = Me.TextBox3.Text  'Editar datos
        TextBox1.Text = fila(0).ToString
        If TextBox2.Text = "" And TextBox3.Text = "" Then
            MessageBox.Show("Falta de dades!")
            Exit Sub
        End If
        fila.EndEdit() 'Finalizar edición
        'Hasta acá se actualizaron los datos, pero sólo en el DATASET

        'Actualizamos los datos en la BD, metodo UPDATE
        Me.CategoriaTableAdapter.Update(Me.NeptunoDataSet1.Categoria)
        Me.listarDatos() 'Volvemos a listar los datos para ver si se cambiaron los datos
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim fila As DataRow = Me.NeptunoDataSet1.Categoria.Rows.Find(Me.DataGridView1.SelectedCells(0).Value)
        fila.Delete()
        'Hasta acá se eliminaron los datos, pero sólo en el DATASET


        'Actualizamos los cambios en la BD, metodo UPDATE
        Me.CategoriaTableAdapter.Update(Me.NeptunoDataSet1.Categoria)
        Me.listarDatos()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim fila As DataRow = Me.NeptunoDataSet1.Categoria.NewRow()

        fila(0) = Me.CategoriaTableAdapter.ScalarQuery + 1 'Nombre de la categoria
        fila(1) = Me.TextBox2.Text  'Editar datos
        fila(2) = Me.TextBox3.Text  'Editar datos
        TextBox1.Text = fila(0).ToString
        If TextBox2.Text = "" And TextBox3.Text = "" Then
            MessageBox.Show("Falta de dades!")
            Exit Sub
        End If
        Me.NeptunoDataSet1.Categoria.Rows.Add(fila)
        'Hasta acá se agregaron los datos, pero sólo en el DATASET

        Me.CategoriaTableAdapter.Update(Me.NeptunoDataSet1.Categoria)
        'Actualizamos los datos en la BD, metodo UPDATE

        Me.listarDatos()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class
