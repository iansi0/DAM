﻿' programa que demani el numero d'alumnes a introduir(array) i fer una estructura amb nom, edat, dni i sexe
' despres un botó que mostrar noms i per mostrar sexe
Public Class Form1

    Structure d_alumnes
        Dim Nom As String
        Dim D_N As Date
        Dim DNI As String
        Dim Sexe As Boolean
        Dim Provincia As String
        Dim Cp As Integer
    End Structure

    Dim alumne() As d_alumnes

    Dim conta As Integer = 0

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim a As Integer

        Me.Size = New System.Drawing.Size(300, 400)

        Button1.Enabled = True
        Button2.Enabled = False
        Button4.Enabled = False
        Button5.Enabled = False
        Button6.Enabled = False
        Button7.Enabled = False

        For b As Integer = 0 To 1000
            a = InputBox("Introduir el nombre d'alumnes:")

            If a > 1 And a < 31 Then
                ReDim alumne(a - 1)
                Exit For
            Else
                MessageBox.Show("El mínim d'alumnes a introduïr és 2 i el màxim 30")
            End If
        Next

        ComboBox1.Items.Add("Barcelona")
        ComboBox1.Items.Add("Girona")
        ComboBox1.Items.Add("Lleida")
        ComboBox1.Items.Add("Tarragona")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Validar_NIF(TextBox3.Text) = False Then
            MessageBox.Show("ERROR DE DADES")
            Exit Sub
        End If
        alumne(conta).Nom = TextBox1.Text
        alumne(conta).D_N = DateTimePicker1.Value
        alumne(conta).DNI = TextBox3.Text
        If RadioButton1.Checked Then
            alumne(conta).Sexe = True
        End If
        If RadioButton2.Checked Then
            alumne(conta).Sexe = False
        End If
        alumne(conta).Provincia = ComboBox1.SelectedItem
        alumne(conta).Cp = TextBox2.Text

        conta = conta + 1

        TextBox1.Clear()
        DateTimePicker1.Value = Now
        TextBox2.Clear()
        ComboBox1.Text = ""
        TextBox3.Clear()
        Button1.Enabled = True
        If conta = UBound(alumne) + 1 Then
            MessageBox.Show("Ja s'han introduit tots els alumnes")
            TextBox1.Enabled = False
            DateTimePicker1.Enabled = False
            TextBox3.Enabled = False
            TextBox2.Enabled = False
            ComboBox1.Enabled = False
            GroupBox1.Enabled = False
            Button1.Enabled = False
            Button2.Enabled = True
            Button4.Enabled = True
            Button5.Enabled = True
            Button6.Enabled = True
            Button7.Enabled = True
        End If


        TextBox1.Focus()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Size = New System.Drawing.Size(600, 00)

        TextBox4.Text = "Noms dels alumnes: " & vbNewLine

        For a As Integer = 0 To conta - 1
            TextBox4.Text = TextBox4.Text & Str(a) & ".  " & alumne(a).Nom & vbNewLine
        Next


    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If InStr(1, "0123456789,.-", e.KeyChar) = 0 Then

            e.Handled = False
        Else
            e.Handled = True

        End If

        If e.KeyChar = ChrW(Keys.Enter) Then

            e.Handled = True
            If TextBox1.Text = "" Then
                MessageBox.Show("Falta el nom")
                Exit Sub
            End If
            DateTimePicker1.Focus()

        End If


    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress

        Dim a As Boolean
        If e.KeyChar = ChrW(Keys.Enter) Then

            e.Handled = True

        End If

        If e.KeyChar = ChrW(Keys.Enter) Then

            e.Handled = True
            a = Validar_NIF(TextBox3.Text)
            If a = False Then
                MessageBox.Show("DNI incorrecte.")
                TextBox3.Focus()
            Else
                RadioButton1.Focus()
            End If

        End If
    End Sub

    Private Sub RadioButton1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles RadioButton1.KeyPress, RadioButton2.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then

            e.Handled = True
            Button1.Enabled = True
            Button1.Focus()

        End If
    End Sub

    Private Sub Button1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Button1.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then

            e.Handled = True
            TextBox1.Focus()

        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Size = New System.Drawing.Size(600, 400)

        TextBox4.Text = "Sexe dels alumnes: " & vbNewLine

        For a As Integer = 0 To conta - 1
            If alumne(a).Sexe = True Then
                TextBox4.Text = TextBox4.Text & Str(a) & ".  " & "Masculí" & vbNewLine
            Else
                TextBox4.Text = TextBox4.Text & Str(a) & ".  " & "Femení" & vbNewLine
            End If

        Next
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim Edat As Integer
        Me.Size = New System.Drawing.Size(600, 400)
        TextBox4.Text = "Edat dels alumnes: " & vbNewLine
        For a = 0 To conta - 1
            Edat = DateDiff(DateInterval.Year, alumne(a).D_N, Now)
            TextBox4.Text = TextBox4.Text & Str(a) & ".  " & Edat & " anys" & vbNewLine
        Next
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim Cp As Integer
        Me.Size = New System.Drawing.Size(600, 400)
        TextBox4.Text = "Codi Postal dels alumnes: " & vbNewLine
        For a = 0 To conta - 1
            Cp = alumne(a).Cp
            TextBox4.Text = TextBox4.Text & Str(a) & ".  " & Cp & vbNewLine
        Next
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim Provincia As String
        Me.Size = New System.Drawing.Size(600, 400)
        TextBox4.Text = "Provincia dels alumnes: " & vbNewLine
        For a = 0 To conta - 1
            Provincia = alumne(a).Provincia
            TextBox4.Text = TextBox4.Text & Str(a) & ".  " & Provincia & vbNewLine
        Next
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If InStr(1, "0123456789,.-" & Chr(8), e.KeyChar) = 0 Then
            e.Handled = True
        Else
            e.Handled = False
        End If

    End Sub
End Class