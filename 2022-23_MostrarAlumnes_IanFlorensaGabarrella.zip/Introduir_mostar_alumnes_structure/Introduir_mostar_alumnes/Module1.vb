﻿Module Module1
    Public Function Validar_NIF(ByVal nif As String) As Boolean
        If nif.Length = 0 Then
            Exit Function
        End If
        Dim aux As String
        nif = UCase(nif) 'ponemos la letra en mayuscula
        aux = Mid(nif, 1, Len(nif) - 1) 'quitamos la letra del nif

        If Len(aux) >= 7 And IsNumeric(aux) Then
            aux = Calcular_NIF(aux, False) 'calculamos la letra del NIF para comparar con la que tenemos
        Else
            MsgBox("El dato introducido no corresponde a un NIF")
            Return False
            Exit Function
        End If

        If nif <> aux Then
            Return False
        Else
            Return True
        End If
    End Function


    Public Function Calcular_NIF(ByVal dni As String, ByVal retornoLetra As Boolean) As String
        Dim resto As Integer
        Dim letra_NIF As String
        letra_NIF = ""
        If dni = "" Then
            MsgBox("No se ha introducido datos", MsgBoxStyle.Information)
            Calcular_NIF = ""
            Exit Function
        ElseIf Len(dni) < 7 Then
            MsgBox("No se puede calcular el NIF porque faltan dígitos", MsgBoxStyle.Information)
            Calcular_NIF = ""
            Exit Function
        ElseIf Not IsNumeric(dni) Then
            MsgBox("El dato introducido no es numérico", MsgBoxStyle.Information)
            Calcular_NIF = ""
            Exit Function
        Else
            resto = Val(dni) Mod 23
            Select Case resto
                Case 0
                    letra_NIF = "T"
                Case 1
                    letra_NIF = "R"
                Case 2
                    letra_NIF = "W"
                Case 3
                    letra_NIF = "A"
                Case 4
                    letra_NIF = "G"
                Case 5
                    letra_NIF = "M"
                Case 6
                    letra_NIF = "Y"
                Case 7
                    letra_NIF = "F"
                Case 8
                    letra_NIF = "P"
                Case 9
                    letra_NIF = "D"
                Case 10
                    letra_NIF = "X"
                Case 11
                    letra_NIF = "B"
                Case 12
                    letra_NIF = "N"
                Case 13
                    letra_NIF = "J"
                Case 14
                    letra_NIF = "Z"
                Case 15
                    letra_NIF = "S"
                Case 16
                    letra_NIF = "Q"
                Case 17
                    letra_NIF = "V"
                Case 18
                    letra_NIF = "H"
                Case 19
                    letra_NIF = "L"
                Case 20
                    letra_NIF = "C"
                Case 21
                    letra_NIF = "K"
                Case 22
                    letra_NIF = "E"

            End Select
            If retornoLetra = True Then
                Return letra_NIF
            Else
                Return dni & letra_NIF
            End If

            Exit Function
        End If

    End Function
End Module
