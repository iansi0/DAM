﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()

        Dim d = Val(InputBox("Dimensio"))
        Dim arr = FerArray(d)
        Application.DoEvents()
        Dim arr2 = FerArray(d)


        For index As Integer = 0 To arr.GetUpperBound(0)
            For index2 As Integer = 0 To arr.GetUpperBound(1)
                TextBox1.Text += arr(index, index2) & " "
            Next
            TextBox1.Text += vbCrLf
        Next
        Dim r = SumarDiagonal(arr, d)
        TextBox1.Text += vbCrLf & vbCrLf & r

        For index As Integer = 0 To arr2.GetUpperBound(0)
            For index2 As Integer = 0 To arr2.GetUpperBound(1)
                TextBox2.Text += arr2(index, index2) & " "
            Next
            TextBox2.Text += vbCrLf
        Next
        Dim r2 = SumarDiagonal(arr2, d)
        TextBox2.Text += vbCrLf & vbCrLf & r2

        Dim arr3 = SumarArray(arr, arr2, d)
        For index As Integer = 0 To arr3.GetUpperBound(0)
            For index2 As Integer = 0 To arr3.GetUpperBound(1)
                TextBox3.Text += arr3(index, index2) & " "
            Next
            TextBox3.Text += vbCrLf
        Next
        Dim r3 = SumarDiagonal(arr3, d)
        TextBox3.Text += vbCrLf & vbCrLf & r3
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()

    End Sub
End Class
