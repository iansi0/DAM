﻿Module Module1
    Function FerArray(d As Integer) As Integer(,) 'Declaracio de que torna un array
        'Dim rndm As New Random
        Dim a(,) As Integer
        d += -1
        ReDim a(d, d)

        For index As Integer = 0 To a.GetUpperBound(0)
            For index2 As Integer = 0 To a.GetUpperBound(1)
                a(index, index2) = (9 * Rnd())

            Next
        Next
        Return a
    End Function
    Function SumarDiagonal(arr As Integer(,), d As Integer) As Integer
        Dim r As Integer
        For index As Integer = 0 To arr.GetUpperBound(0)
            For index2 As Integer = 0 To arr.GetUpperBound(1)
                If index = index2 Then
                    r += arr(index, index2)
                End If
            Next
        Next

        Return r
    End Function
    Function SumarArray(arr As Integer(,), arr2 As Integer(,), d As Integer) As Integer(,)
        Dim a(,) As Integer
        d += -1
        ReDim a(d, d)
        For index As Integer = 0 To arr.GetUpperBound(0)
            For index2 As Integer = 0 To arr.GetUpperBound(1)
                If arr(index, index2) < arr2(index, index2) Then
                    a(index, index2) = arr2(index, index2)
                Else
                    a(index, index2) = arr(index, index2)
                End If
            Next
        Next
        Return a
    End Function
End Module
